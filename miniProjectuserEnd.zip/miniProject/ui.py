import sys
from AnimatedGif import *

global s1,s2,s3,s4,L,L1,F,F1

try:
    from Tkinter import *
except ImportError:
    from tkinter import *

try:
    import ttk
    py3 = 0
except ImportError:
    import tkinter.ttk as ttk
    py3 = 1



 
 
def Fgif(ind) :
	
    frame = Fan[ind]
    ind += 1
    fanOn.configure(image=frame)
    if (ind > 2) :
    		ind = 2
    top.after(100, Fgif, ind)
    
def F1gif(ind) :
	
    frame = Fan[ind]
    ind += 1
    if (ind > 2) :
	ind = 2
    fan1On.configure(image=frame)
    top.after(100, F1gif, ind)

def Hgif(ind) :
	
    frame = House[ind]
    if(ind<=1) :
        ind += 1
    Label3.configure(image=frame)
    top.after(1000, Hgif, ind)

def ChangeLights():
	
	global s1,L
	
	print (L)
	
	if (s1 == 0) :
		s1 = 1
		L = 1 
		lightOff.place()
		lightOff.place_forget()
	elif (s1 == 1) :
		s1 = 0
		L = 0 
		lightOff.place(relx=0.03, rely=0.05, height=158, width=206)

 
def ChangeLights1():
	
	global s2,L1
	
	print (L1)
	
	if (s2 == 0) :
		s2 = 1
		L1 = 1
		light1Off.place()
		light1Off.place_forget()
	elif (s2 == 1) :
		s2 = 0
		L1 = 0
		light1Off.place(relx=0.73, rely=0.05, height=158, width=206)
	

	
def ChangeFan():
	
	global s3,F
	
	print (F)
	
	if (s3 == 0) :
		s3 = 1
		F = 1
		fanOff.place()
		fanOff.place_forget()
	elif (s3 == 1) :
		s3 = 0
		F = 0
		fanOff.place(relx=0.01, rely=0.56, height=218, width=286)
	

	
def ChangeFan1():
	
	global s4,F1
	
	print (F1)
	
	if (s4 == 0) :
		s4 = 1
		F1 = 1
		fan1Off.place()
		fan1Off.place_forget()
	elif (s4 == 1) :
		s4 = 0
		F1 = 0
		fan1Off.place(relx=0.67, rely=0.57, height=228, width=286)
	
	    

top = Tk()

_bgcolor = '#d9d9d9'  # X11 color: 'gray85'
_fgcolor = '#000000'  # X11 color: 'black'
_compcolor = '#d9d9d9' # X11 color: 'gray85'
_ana1color = '#d9d9d9' # X11 color: 'gray85' 
_ana2color = '#d9d9d9' # X11 color: 'gray85' 
style = ttk.Style()

if sys.platform == "win32":
  style.theme_use('winnative')

style.configure('.',background=_bgcolor)
style.configure('.',foreground=_fgcolor)
style.configure('.',font="TkDefaultFont")
style.map('.',background=
  [('selected', _compcolor), ('active',_ana2color)])

top.geometry("1103x887+433+78")
top.title("New Toplevel 1")
top.configure(background="#000000")



Frame1 = Frame(top)
Frame1.place(relx=0.03, rely=0.05, relheight=0.72, relwidth=0.95)
Frame1.configure(relief=GROOVE)
Frame1.configure(borderwidth="2")
Frame1.configure(relief=GROOVE)
Frame1.configure(background="#ffd9d9")
Frame1.configure(width=1045)

lightOn = Label(Frame1)
lightOn.place(relx=0.03, rely=0.05, height=158, width=206)
lightOn.configure(activebackground="#ffecec")
lightOn.configure(background="#ffd9d9")
_img1 = PhotoImage(file="../lightbulbglow.png")
lightOn.configure(image=_img1)
lightOn.configure(text='''Label''')
lightOn.configure(width=206)



lightOff = Label(Frame1)
lightOff.place(relx=0.03, rely=0.05, height=158, width=206)
lightOff.configure(activebackground="#ffecec")
lightOff.configure(background="#ffd9d9")
_img2 = PhotoImage(file="../lightbulboff.png")
lightOff.configure(image=_img2)
lightOff.configure(text='''Label''')
lightOff.configure(width=206)



fanOn = Label(Frame1)
fanOn.place(relx=0.03, rely=0.6, height=168, width=246)
fanOn.configure(activebackground="#f9f9f9")
fanOn.configure(background="#ffd9d9")
_img3 = PhotoImage(file="../fanRun.gif")
fanOn.configure(image=_img3)
fanOn.configure(text='''Label''')
fanOn.configure(width=246)



fanOff = Label(Frame1)
fanOff.place(relx=0.01, rely=0.56, height=218, width=286)
fanOff.configure(activebackground="#f9f9f9")
fanOff.configure(background="#ffd9d9")
_img4 = PhotoImage(file="../fanOff3.png")
fanOff.configure(image=_img4)
fanOff.configure(text='''Label''')
fanOff.configure(width=286)


fan1On = Label(Frame1)
fan1On.place(relx=0.67, rely=0.62, height=168, width=246)
fan1On.configure(activebackground="#f9f9f9")
fan1On.configure(background="#ffd9d9")
_img5 = PhotoImage(file="../fanRun.gif")
fan1On.configure(image=_img5)
fan1On.configure(text='''Label''')
fan1On.configure(width=246)


fan1Off = Label(Frame1)
fan1Off.place(relx=0.67, rely=0.57, height=228, width=286)
fan1Off.configure(activebackground="#f9f9f9")
fan1Off.configure(background="#ffd9d9")
_img6 = PhotoImage(file="../fanOff3.png")
fan1Off.configure(image=_img6)
fan1Off.configure(text='''Label''')
fan1Off.configure(width=286)


light1On = Label(Frame1)
light1On.place(relx=0.73, rely=0.05, height=158, width=206)
light1On.configure(activebackground="#f9f9f9")
light1On.configure(background="#ffd9d9")
_img7 = PhotoImage(file="../lightbulbglow.png")
light1On.configure(image=_img7)
light1On.configure(text='''Label''')
light1On.configure(width=206)


light1Off = Label(Frame1)
light1Off.place(relx=0.73, rely=0.05, height=158, width=206)
light1Off.configure(activebackground="#f9f9f9")
light1Off.configure(background="#ffd9d9")
_img8 = PhotoImage(file="../lightbulboff.png")
light1Off.configure(image=_img8)
light1Off.configure(text='''Label''')
light1Off.configure(width=206)

Label3 = Label(Frame1)
Label3.place(relx=0.34, rely=0.3, height=308, width=326)
Label3.configure(background="#ffd9d9")
_img9 = PhotoImage(file="../home-animated-pastels.gif")
Label3.configure(image=_img9)
Label3.configure(text='''Label''')
Label3.configure(width=326)

Label4 = Label(Frame1)
Label4.place(relx=0.22, rely=0.02, height=188, width=566)
Label4.configure(background="#ffd9d9")
_img10 = PhotoImage(file="../homeText.png")
Label4.configure(image=_img10)
Label4.configure(text='''Label''')
Label4.configure(width=566)

OKbutton2 = ttk.Button(top)
OKbutton2.place(relx=0.43, rely=0.79, height=135, width=153)
OKbutton2.configure(takefocus="")
_img11 = PhotoImage(file="../send.png")
OKbutton2.configure(image=_img11)

Button1 = Button(Frame1)
Button1.place(relx=0.1, rely=0.91, height=26, width=77)
Button1.configure(activebackground="#d9d9d9")
Button1.configure(text='''CHANGE3''')
Button1.configure(command=ChangeFan)

s1 = 0
s2 = 1
s3 = 1
s4 = 0
L = 1
L1 = 1
F = 1
F1 = 1

Fan = [PhotoImage(file='../fanRun.gif', format = 'gif -index %i' %i) for i in range(5)]
House = [PhotoImage(file='../home-animated-pastels.gif', format = 'gif -index %i' %i) for i in range(2)]
 

ChangeLights()
ChangeLights1()
ChangeFan()
ChangeFan1()

Button2 = Button(Frame1)
Button2.place(relx=0.1, rely=0.35, height=26, width=77)
Button2.configure(activebackground="#d9d9d9")
Button2.configure(text='''CHANGE1''')
Button2.configure(command=ChangeLights)

Button3 = Button(Frame1)
Button3.place(relx=0.79, rely=0.35, height=26, width=77)
Button3.configure(activebackground="#d9d9d9")
Button3.configure(text='''CHANGE2''')
Button3.configure(command=ChangeLights1)


Button4 = Button(Frame1)
Button4.place(relx=0.78, rely=0.92, height=26, width=77)
Button4.configure(activebackground="#d9d9d9")
Button4.configure(text='''CHANGE4''')
Button4.configure(command=ChangeFan1)


menubar = Menu(top,font="TkMenuFont",bg=_bgcolor,fg=_fgcolor)
top.configure(menu = menubar)


top.after(0, Hgif, 0)


top.mainloop()
